function test_newton2D()
  
    
    x0=2;
    tol = 1e-8;
    
    x = newton2D(@f,@jacobian,x0,1e-8);
    
    fprintf('x1 = %f,x2 = %f,x3 = %f,x4 = %f\n',x(1),x(2),x(3),x(4));
end