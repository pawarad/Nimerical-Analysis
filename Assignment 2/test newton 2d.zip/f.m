function [z] = f(x)
   global params
    x(1) = params.x(1);
    x(2) = params.x(2);
    x(3) = params.x(3);
    x(4) = params.x(4);
  

z = zeros(4,1); %4*1 matrix

z(1)= x(1)+x(2)+x(3)+x(4)-2.5;
z(2)= x(1)*(x(2)+x(3)+x(4))+x(2)*(x(3)+x(4))+x(3)*x(4)-2.7;
z(3)= x(1)*x(2)*(x(3)+x(4))+x(3)*x(4)*(x(1)+x(2))-0.52;
z(4)= x(1)*x(2)*x(3)*x(4)+0.48;

end