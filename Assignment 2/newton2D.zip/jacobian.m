function [z]=jacobian(x)
global params
  x1 = params.x1;
  x2 = params.x2;
  x3 = params.x3;
  x4 = params.x4;

  z = zeros(4,4);%create return as 4*4 matrix
  z(1,1)= 1;
  z(1,2)= 1;
  z(1,3)= 1; 
  z(1,4)= 1;
  z(2,1)= x2+x3+x4;
  z(2,2)= x1+x3+x4;
  z(2,3)= x1+x2+x4;
  z(2,4)= x1+x2+x3;
  z(3,1)= x2*x3+x2*x4+x2*x3*x4;
  z(3,2)= x1*(x3+x4+x3*x4);
  z(3,3)= x2*(x1+x1*x3);
  z(3,4)= x1*x2+x1*x2*x3;
  z(4,1)= x2*x3*x4;
  z(4,2)= x1*x3*x4;
  z(4,3)= x1*x2*x4;
  z(4,4)= x1;x2;x3;

end