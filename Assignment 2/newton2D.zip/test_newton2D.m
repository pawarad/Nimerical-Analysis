function test_newton2D()
  global params
    x1 = params.x1;
    x2 = params.x2;
    x3 = params.x3;
    x4 = params.x4;
    
    x0=2;
    tol = 1e-8;
    
    x = newton2D(f,jacobian,x0,1e-8);
    
    fprintf('x1 = %f,x2 = %f,x3 = %f,x4 = %f\n',x1,x2,x3,x4);
end