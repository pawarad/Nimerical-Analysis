function [z] = f(x)
  global params
  x1 = params.x1;
  x2 = params.x2;
  x3 = params.x3;
  x4 = params.x4;

z = zeros(4,1); %4*1 matrix

z(1)= x1+x2+x3+x4-2.5;
z(2)= x1*(x2+x3+x4)+x2*(x3+x4)+x3*x4-2.7;
z(3)= x1*x2*(x3+x4)+x3*x4(x1+x2)-0.52;
z(4)= x1*x2*x3*x4+0.48;

end