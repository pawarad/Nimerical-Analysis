1) Computing powers of x over and over is a time consuming function call.So we use Honor's rule for summing series.

2) When we keep tolerance of 1e-6 the function converges till x=44 and when the x increased the absolute difference goes beyond the tolenrance limit.
